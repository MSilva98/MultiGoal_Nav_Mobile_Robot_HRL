"""epuck_follow_the_line_controller controller."""

# You may need to import some classes of the controller module. Ex:
#  from controller import Robot, Motor, DistanceSensor
from controller import Robot

# create the Robot instance.
robot = Robot()

# get the time step of the current world.
timestep = int(robot.getBasicTimeStep())

# You should insert a getDevice-like function in order to get the
# instance of a device of the robot. Something like:
#  motor = robot.getMotor('motorname')
#  ds = robot.getDistanceSensor('dsname')
#  ds.enable(timestep)

global_speed = 1.5
fs_speed = 0.2
threshold = 350
MAX_SPEED = 6.28


# initialize devices
pg = []
pgNames = [
    'gs0', 'gs1', 'gs2'
]

for i in range(3):
    pg.append(robot.getDistanceSensor(pgNames[i]))
    pg[i].enable(timestep)
    
ps = []
psNames = [
    'ps0', 'ps1', 'ps2', 'ps3',
    'ps4', 'ps5', 'ps6', 'ps7'
]

for i in range(8):
    ps.append(robot.getDistanceSensor(psNames[i]))
    ps[i].enable(timestep)


leftMotor = robot.getMotor('left wheel motor')
rightMotor = robot.getMotor('right wheel motor')
leftMotor.setPosition(float('inf'))
rightMotor.setPosition(float('inf'))
leftMotor.setVelocity(0.0)
rightMotor.setVelocity(0.0)

# Main loop:
# - perform simulation steps until Webots is stopping the controller
while robot.step(timestep) != -1:
    # read sensors outputs
    floor_sensors = []
    for i in range(3):
        floor_sensors.append(pg[i].getValue())
        
    #print(floor_sensors)
    
    # line_follower
    # delta = abs(floor_sensors[2] - floor_sensors[0])
    if floor_sensors[2] < threshold and floor_sensors[0] > threshold and floor_sensors[1] > threshold :
        l_speed = global_speed + fs_speed * MAX_SPEED
        r_speed = global_speed - fs_speed * MAX_SPEED    
        
    elif floor_sensors[2] > threshold and floor_sensors[0] < threshold and floor_sensors[1] > threshold:
        l_speed = global_speed - fs_speed * MAX_SPEED
        r_speed = global_speed + fs_speed * MAX_SPEED
        
    elif floor_sensors[2] < threshold and floor_sensors[0] < threshold and floor_sensors[1] < threshold:
        l_speed = global_speed - fs_speed * MAX_SPEED
        r_speed = global_speed + fs_speed * MAX_SPEED
       
    else:
        psValues = []
        for i in range(8):
            psValues.append(ps[i].getValue())
        
        # detect obstacles
        right_obstacle = psValues[0] > 80.0 or psValues[1] > 80.0 or psValues[2] > 80.0
        left_obstacle = psValues[5] > 80.0 or psValues[6] > 80.0 or psValues[7] > 80.0
        # modify speeds according to obstacles
        l_speed = 0.5 * MAX_SPEED
        r_speed = 0.5 * MAX_SPEED
        if left_obstacle:
            # turn right
            l_speed  += 0.5 * MAX_SPEED
            r_speed -= 0.5 * MAX_SPEED
        elif right_obstacle:
            # turn left
            l_speed  -= 0.5 * MAX_SPEED
            r_speed += 0.5 * MAX_SPEED
        
           
				
    # Now, we set the motor speed. Remember that we need to execute 'step()'
    # for make this command effective
    leftMotor.setVelocity(l_speed)
    rightMotor.setVelocity(r_speed)
    


# Enter here exit cleanup code.
