LaTeX Thesis Template
==========================================
University of Aveiro, Portugal
------------------------------------------

Latex thesis template of the University of Aveiro made by Tomás Oliveira e Silva.

Sharing it for the sake of preservation.
